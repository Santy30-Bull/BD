USE AdventureWorks2017

-- TRIGGERS

--AFTER INSERT, UPDATE
CREATE TRIGGER reminder_InsertUpdate
ON Sales.Customer
AFTER INSERT, UPDATE
AS RAISERROR ('Notify customer relations', 16, 10)
GO

INSERT INTO Sales.Customer (PersonID, StoreID, TerritoryID, rowguid, ModifiedDate)
VALUES (1, 934, 1, NEWID(), GETDATE());

UPDATE Sales.Customer
SET TerritoryID = 4
WHERE YEAR(ModifiedDate) = 2024;

DELETE FROM Sales.Customer
WHERE YEAR(ModifiedDate) = 2024;

SELECT * FROM Sales.Customer
ORDER BY ModifiedDate DESC;


-- Trigger para guardar una tabla de hist�rico de actualizaciones de productos, el id del producto 
-- y la fecha de modificaci�n cada vez que se haga un update en la tabla de productos

-- Crear tabla hist�ricos
CREATE TABLE Production.Test_Trigger_Product_Hist (ProductID int NOT NULL, ModifiedDate DATETIME NOT NULL)

-- Trigger
CREATE OR ALTER TRIGGER Production.TR_UDP_Product ON Production.Product
FOR UPDATE 
-- NOT FOR REPLICATION
AS
BEGIN
	INSERT INTO Production.Test_Trigger_Product_Hist
	SELECT ProductID, GETDATE()
	FROM INSERTED -- Fila insertada en la acci�n de UPDATE
END

SELECT * FROM Production.Product
WHERE Color = 'Without Color';


-- Cambiar el color de nulo a Without color
UPDATE Production.Product
SET Color = 'Without Color'
WHERE Color IS NULL;

-- Cambiar el color de Without color a nulo
UPDATE Production.Product
SET Color = NULL
WHERE Color = 'Without Color';


-- Tabla hist�rico
SELECT * FROM Production.Test_Trigger_Product_Hist;


-- Cada vez que se elimine, inserte o se modifique la tabla guardar el hist�rico

CREATE TABLE TestProduct (ProductID INT NOT NULL,
							Name NVARCHAR(50),
							Color NVARCHAR(15))
CREATE TABLE TestProduct_Hist (ProductID INT NOT NULL,
								NodifiedDate DATETIME,
								ModifiedBy VARCHAR(128),
								Operation CHAR(1))

INSERT INTO TestProduct 
SELECT ProductID, Name, Color FROM Production.Product

-- Saber quien est� logueado en la base de datos
SELECT login_name
FROM sys.dm_exec_sessions
WHERE session_id = @@SPID

CREATE OR ALTER TRIGGER TR_UDP_Product ON TestProduct
FOR INSERT, UPDATE, DELETE
AS
BEGIN
    DECLARE @ProductID INT;
    DECLARE @ModifiedBy NVARCHAR(128);

	SET @ModifiedBy = (SELECT login_name
                        FROM sys.dm_exec_sessions
                        WHERE session_id = @@SPID);

    IF EXISTS (SELECT 1 FROM INSERTED) AND EXISTS (SELECT 1 FROM DELETED)
    BEGIN
        SELECT TOP 1 @ProductID = ProductID FROM INSERTED;
        INSERT INTO TestProduct_Hist VALUES (@ProductID, GETDATE(), @ModifiedBy, 'U');
    END
    ELSE IF EXISTS (SELECT 1 FROM INSERTED)
    BEGIN
        SELECT TOP 1 @ProductID = ProductID FROM INSERTED;
        INSERT INTO TestProduct_Hist VALUES (@ProductID, GETDATE(), @ModifiedBy, 'I');
    END
    ELSE
    BEGIN
        SELECT TOP 1 @ProductID = ProductID FROM DELETED;
        INSERT INTO TestProduct_Hist VALUES (@ProductID, GETDATE(), @ModifiedBy, 'D');
    END
END;

INSERT INTO TestProduct VALUES (10000, 'New', 'Red');

UPDATE TestProduct
SET Color = 'Blue'
WHERE ProductID = 1;

DELETE FROM TestProduct WHERE ProductID = 10000;

SELECT * FROM TestProduct_Hist


-- INSTEAD OF

-- Evita que se ejecute el delete
CREATE TRIGGER TR_DEL_Products ON TestProduct
INSTEAD OF DELETE
AS
BEGIN
	SELECT 'Sample Instead of trigger' AS Message
END

DELETE FROM TestProduct WHERE ProductID = 1
DELETE FROM TestProduct

SELECT * FROM TestProduct
		
		


