Create Database Test;
Use Test

Create table Area (
ID_Area INT IDENTITY (1,1) PRIMARY KEY,
Name_Area VARCHAR (255) 
);

Create Table Professor(
ID INT IDENTITY (1,1) PRIMARY KEY,
Name_prof VARCHAR (255),
ID_Area Int,
FOREIGN KEY (ID_Area) REFERENCES Area(ID_Area) ON DELETE CASCADE
);

INSERT INTO Area (Name_Area)
Values
('Civil'),
('Sistemas'),
('Mecaestupidos');

INSERT INTO Professor (Name_prof, ID_Area)
Values
('Angel Garcia',2),
('Andrea Diaz',1),
('Rafael P�rez',3),
('Alberto Molina',2);

select * from Professor
Select * from Area


--Inner Join: Todos los metodos sacan lo mimo, excepto la 3.
--1 way
	SELECT p.Name_prof, a.Name_Area 
	FROM Area as a, Professor as p
	WHERE a.ID_Area=p.ID_Area
--2 way
	SELECT p.Name_prof,a.Name_Area
	FROM Area as a INNER JOIN Professor as p ON a.ID_Area=p.ID_Area
--3 way 
	SELECT *
	FROM Area as a INNER JOIN Professor as p ON a.ID_Area=p.ID_Area


--Cross Join: Todas las combinaciones posibles de todo con todo
--1 way
	SELECT *
	FROM Area as a, Professor as p
--2 way
	SELECT * 
	FROM Area CROSS JOIN Professor


--Outer Join: Cuando necesite encontrar datos que esten o no relacionado: Se puede poner por la izq � por la dere. O full
	SELECT *
	FROM Professor LEFT OUTER JOIN Area ON Professor.ID_Area=Area.ID_Area

	SELECT *
	FROM Area LEFT OUTER JOIN Professor ON Area.ID_Area=Professor.ID_Area

	SELECT *
	FROM Area RIGHT OUTER JOIN Professor ON Area.ID_Area=Professor.ID_Area

	SELECT *
	FROM Professor RIGHT OUTER JOIN Area ON Professor.ID_Area=Area.ID_Area

	SELECT *
	FROM Professor FULL OUTER JOIN Area ON Professor.ID_Area=Area.ID_Area

--Alterar Profesor; para probar los JOINS
ALTER TABLE Professor 
ADD Age int NULL;

	UPDATE Professor
	SET Age = 
		CASE 
			WHEN Name_Prof = 'Angel Garcia' THEN 34
			WHEN Name_Prof = 'Andrea Diaz' THEN 36
			WHEN Name_Prof = 'Rafael P�rez' THEN 40
			WHEN Name_Prof = 'Alberto Molina' THEN 55
		END;

Insert into Professor (Name_prof,Age)
Values
('Gustavo Diaz',44);

Insert into Area (Name_Area)
VALUES
('Isislovers');

--Los Wheres
	--Profes con area en sistemas
	Select Professor.Name_prof
	From Professor INNER JOIN Area on Professor.ID_Area=Area.ID_Area
	WHERE Area.Name_Area='Sistemas'
	--Profes con apellido Diaz
	Select Professor.Name_prof
	From Professor
	WHERE Name_prof LIKE ('%Diaz%') --Los porcentajes sirven para buscar en todo el string; no como tal solo diaz sino en cualquier parte
	--Profe con mas de 40
	Select Professor.Name_prof
	From Professor
	WHERE age > 40
	--Profes con mas de 40 y que esten en sistemas
	Select Professor.Name_prof, Area.Name_Area
	From Professor INNER JOIN Area ON
	Professor.ID_Area=Area.ID_Area
	WHERE age > 40 AND Area.Name_Area='Sistemas'
	--Profes de sistema y de mecaestupidos
	Select Professor.Name_prof,Area.Name_Area
	From Professor INNER JOIN Area ON
	Professor.ID_Area=Area.ID_Area
	WHERE Area.Name_Area='Sistemas' OR Area.Name_Area='Mecaestupidos'


--Los Order By; se puede ascendente o descendente (ASC � DESC)
	--Profes con 40 o mas, ordenado en ascendente 
	SELECT Professor.Name_prof, age
	FROM Professor
	WHERE age > 40
	ORDER BY age ASC
	--Profes con 40 o mas, ordenado en descendete
	SELECT Professor.Name_prof, age
	FROM Professor
	WHERE age > 40
	ORDER BY age DESC

--Los group by; agrupan por determinados campos (Mediante funciones)
	--Sacar el numero de profes en cada area
	SELECT Area.Name_Area, COUNT (Professor.ID) AS Number_Professors
	FROM Professor INNER JOIN Area ON Professor.ID_Area=Area.ID_Area
	GROUP BY Area.Name_Area
	--Edad maxima en cada una de las areas
	SELECT Area.Name_Area, MAX (Professor.age) AS 'Pa� la morgue'
	From Professor INNER JOIN Area ON Professor.ID=Area.ID_Area
	GROUP BY Area.Name_Area
	--Sacar el area que no tiene profes
	SELECT Area.Name_Area, COUNT (Professor.ID) AS Number_Professors
	FROM Professor RIGHT OUTER JOIN Area ON Professor.ID_Area=Area.ID_Area
	GROUP BY Area.Name_Area

--Los having; son condicionales pero sobre los grupos que se crearon en el group by.
	--Area que tiene mas de 1 profesor 
	SELECT Area.Name_Area, COUNT (Professor.ID) AS Number_Professors
	FROM Professor INNER JOIN Area ON Professor.ID_Area=Area.ID_Area
	GROUP BY Area.Name_Area
	HAVING COUNT (Professor.Name_prof) > 1
	--Area que no tiene profes
	SELECT Area.Name_Area, COUNT (Professor.ID) AS Number_Professors
	FROM Professor RIGHT OUTER JOIN Area ON Professor.ID_Area=Area.ID_Area
	GROUP BY Area.Name_Area
	HAVING COUNT (Professor.Name_prof) = 0

--Los views; sirven para crear una visualizacion (una tabla virtual) de la querie.
	CREATE VIEW  
