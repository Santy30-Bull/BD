use pruebas;

Create table products (
    ProductID int Primary key,
    ProductName nvarchar(50) unique
)

create table sales (
    SaleID int Primary key,
    ProductID int,
    SalesDate date Default getdate(),
    Quantity int,
    Constraint FK_SalesProduct Foreign key (ProductID) references products(ProductID), 
    Constraint CHK_SalesQuantity Check (Quantity > 0)
)

--bien
Insert into products (ProductID, ProductName)
values (1, 'Laptop');
--bien
Insert into sales (SaleID, ProductID, Quantity)
values (1, 1, 5);
--mal 
Insert into sales (SaleID, ProductID, Quantity)
values (2, 1, -3);
--mal
insert into products (ProductID, ProductName)
values (2, 'laptop');