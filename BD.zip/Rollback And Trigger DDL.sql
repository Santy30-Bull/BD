/* Sintaxis del rollback; pueden ser implicitos o explicitos */

-- Rollback implicito; 

Use AdventureWorks2017;
Update TestProduct 
SET color = 'null'
Where ProductID = 1;
Rollback

Set implicit_transactions on;
Update TestProduct 
SET color = 'Without Color'
Where ProductID = 1;
Rollback

SELECT * FROM TestProduct Order by ProductID;

Rollback

-- Rollback explicito;
Set implicit_transactions off;

BEGIN TRANSACTION Demotran1;
insert into TestProduct
values (2000000,'NewTranc1','Red')
Rollback TRANSACTION

Select * from TestProduct Order by ProductID desc ;

Begin Transaction Demotran2;
insert into TestProduct
values (2000001,'NewTranc2','Blue')
Commit Transaction Demotran2 -- Commit para guardar los cambios; para siempre. No se puede deshacer.

Select * from TestProduct Order by ProductID desc ;

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
/* Triggers DDL, se ejecutan sobre el server o la base de datos */

--Crear trigger para saber cuando se crea o elimina una tabla
Create or Alter trigger ddl_db_create
ON DATABASE 
for DROP_TABLE, CREATE_TABLE
AS
    PRINT 'Create New Table or Delete Table '

--Ejecutar el trigger
Create Table NewTable (Column1 int);
Drop Table NewTable;

--Eliminar el trigger
Drop Trigger ddl_db_create on DATABASE


--Funcion de eventdata() para obtener informacion de la accion que se ejecuto
Create or Alter trigger ddl_db_create
ON DATABASE
for DROP_TABLE, CREATE_TABLE
AS
    PRINT 'Create New table'

    declare @data xml;
    set @data = eventdata(); --Obtener informacion de la accion que se ejecuto; se guarda en un xml para poder leerlo despues
    print convert(nvarchar(max),@data)

--Ejecutar el trigger
Create Table NewTable (Column1 int);
Drop Table NewTable;

--Eliminar el trigger
Drop Trigger ddl_db_create on DATABASE

--Crear table para logs de las acciones sobre tablas;cogiendo los eventos sobre las tablas
Create Table dbo.logs(
    logID int identity(1,1) not null Primary Key,
    PostTime datetime not null,
    DatabaseUserName sysname not null,
	event_log sysname not null,
    SchemaName sysname not null,
    ObjectName sysname not null,
    TSQL_Command NVARCHAR(max) not null,
    XMLEvent xml not null
    );



CREATE OR ALTER Trigger ddl_trig_database
on database
for DDL_DATABASE_LEVEL_EVENTS
as
    DECLARE @data xml;
    DECLARE @SchemaName sysname;
    DECLARE @ObjectName sysname;
    DECLARE @event_type sysname;
    DECLARE @DatabaseUserName sysname;
    DECLARE @TSQL_Command NVARCHAR(max);
    PRINT convert(nvarchar(max), @data);
    SET @data = eventdata();
    SET @SchemaName = @data.value('(/EVENT_INSTANCE/SchemaName)[1]','sysname');
    SET @ObjectName = @data.value('(/EVENT_INSTANCE/ObjectName)[1]','sysname');
    SET @event_type = @data.value('(/EVENT_INSTANCE/EventType)[1]','sysname');
    SET @DatabaseUserName = @data.value('(/EVENT_INSTANCE/LoginName)[1]','sysname');
    SET @TSQL_Command = @data.value('(/EVENT_INSTANCE/TSQLCommand)[1]','NVARCHAR(max)');
    INSERT INTO dbo.logs
    Values (
        GETDATE(),
		@DatabaseUserName,
        @event_type,
        CONVERT (sysname, @SchemaName),
        CONVERT (sysname, @ObjectName),
		@TSQL_Command,
        @data
        );

--Muestra la tabla de logs
Select * from dbo.logs

--Ejecutar el trigger
Create Table NewTable (Column1 int);
Drop Table NewTable;

--drop el trigger
Drop Trigger ddl_trig_database on DATABASE


--Trigger para el servidor
Create or Alter trigger ddl_trig_server
ON ALL SERVER
for CREATE_DATABASE
as  
    DECLARE @data xml;
    DECLARE @db sysname;
    DECLARE @event_type sysname;
    DECLARE @DatabaseUserName sysname;
    SET @data = eventdata();
    SET @db = @data.value('(/EVENT_INSTANCE/DatabaseName)[1]','sysname');
    SET @event_type = @data.value('(/EVENT_INSTANCE/EventType)[1]','sysname');
    SET @DatabaseUserName = @data.value('(/EVENT_INSTANCE/LoginName)[1]','sysname');
    PRINT 'NEW DATABASE CREATED: ' + @db + ' BY ' + @DatabaseUserName

CREATE DATABASE NewDatabase;
drop database NewDatabase;

--Trigger para el servidor; que no deje borrar base de datos
Create or Alter trigger ddl_trig_server
ON ALL SERVER
for DROP_DATABASE
as  
	PRINT 'DROP DATABASE SAPA'
    RAISERROR('No se puede borrar la base de datos',16,1)
	ROLLBACK TRAN

--Drop Trigger ddl_trig_server ON ALL SERVER 

SELECT name
FROM sys.triggers --Sirve para saber que trigger hay en la BD, solo date cuenta que bd estas usando