/* Sintaxis del rollback; pueden ser implicitos o explicitos */

-- Rollback implicito; 

Use AdventureWorks2017;
Update TestProduct 
SET color = 'null'
Where ProductID = 1;
Rollback

Set implicit_transactions on;
Update TestProduct 
SET color = 'Without Color'
Where ProductID = 1;
Rollback

SELECT * FROM TestProduct Order by ProductID;

Rollback

-- Rollback explicito;
Set implicit_transactions off;

BEGIN TRANSACTION Demotran1;
insert into TestProduct
values (2000000,'NewTranc1','Red')
Rollback TRANSACTION

Select * from TestProduct Order by ProductID desc ;

Begin Transaction Demotran2;
insert into TestProduct
values (2000001,'NewTranc2','Blue')
Commit Transaction Demotran2 -- Commit para guardar los cambios; para siempre. No se puede deshacer.

Select * from TestProduct Order by ProductID desc ;