use Sales

--Lista de datos (entera) de customers
select * from Customer

--Lista de datos de customers que esten en una order/realizar orden 
SELECT DISTINCT c. * 
From SalesOrder as s INNER JOIN Customer as c on s.TypeIDCustomer =c.TypeID and s.IDCustomer = c.ID

--Order number, request date and delivery date of delivered orders
SELECT SalesOrder.OrderNumber, SalesOrder.RequestDate, FinalSales.CompletionDate
FROM SalesOrder, FinalSales
ORDER BY RequestDate DESC, CompletionDate DESC

--Lista de empleados que vendan mas de 8 ordenes, sorteado por el numero de ordenes vendidas
SELECT Employee.ID, COUNT (SalesOrder.IDEmployee) AS Number_Ventas
FROM Employee INNER JOIN SalesOrder ON Employee.ID=SalesOrder.IDEmployee
GROUP BY Employee.ID
HAVING COUNT (SalesOrder.IDEmployee) > 8

--Sales orders que no han sido puestas en una date completed
SELECT *
FROM SalesOrder LEFT OUTER JOIN FinalSales ON SalesOrder.OrderNumber= FinalSales.OrderNumber
WHERE FinalSales.OrderNumber is null 

--Por cada sales order; el precio total conciderando el descuento
SELECT SalesDetails.OrderNumber,  
SUM (Price*(1-Discount/100)*Quantity) AS Precio
FROM SalesDetails INNER JOIN Product ON SalesDetails.ProductCode = Product.Code
group by SalesDetails.OrderNumber

CREATE or ALTER VIEW  PrecioTotal_ordenes 
as 
SELECT SalesDetails.OrderNumber,  
SUM (Price*(1-Discount/100)*Quantity) AS Precio
FROM SalesDetails INNER JOIN Product ON SalesDetails.ProductCode = Product.Code
group by SalesDetails.OrderNumber

--Monto total de ventas en el a�o 2012
Select CAST (SUM (TotalPrice) as money) as total
From TotalPrice_SalesOrder as P inner join FinalSales on P.OrderNumber=FinalSales.OrderNumber
Group by YEAR(FinalSales.CompletionDate)
Having YEAR(FinalSales.CompletionDate)=2012

--Monto total de ventas en los diferentes a�os
Select CAST (SUM (TotalPrice) as money) as total
From TotalPrice_SalesOrder as P inner join FinalSales on P.OrderNumber=FinalSales.OrderNumber
Group by YEAR(FinalSales.CompletionDate)

--Todos los montos por a�o mayores a 120 millones
SELECT YEAR (FinalSales.CompletionDate) as Year_Sale, CAST(SUM(TotalPrice) as money) as Total
From TotalPrice_SalesOrder as P inner join FinalSales on P.OrderNumber = FinalSales.OrderNumber
Group by YEAR(FinalSales.CompletionDate)
Having SUM(TotalPrice)>120000000


------Subqueries/ Sub consultas
--Quiero saber el producto/productos con mayor precio
Select Product.ProductName, Product.Price
from Product
where Price =(
	select MAX (Price)
	from Product
)
--Cantidades que no fueron 
Select Employee.FirstName, Employee.LastName, 
COUNT (SalesOrder.OrderNumber) as unsoldnumber
from Employee inner join
SalesOrder on Employee.ID= SalesOrder.IDEmployee
where SalesOrder.OrderNumber not in (
select OrderNumber 
from FinalSales
)
group by Employee.ID,Employee.FirstName, Employee.LastName

--Productos que no se vendieron en el actual mes del a�o 2012
Select Product.Code, Product.ProductName, MONTH(getdate()), YEAR(getdate())
From Product
Where code not in 
(select SalesDetails.ProductCode from
SalesOrder inner join SalesDetails on SalesOrder.OrderNumber= SalesDetails.OrderNumber
where MONTH(SalesOrder.RequestDate)= MONTH(getdate()) and YEAR(SalesOrder.RequestDate)=2012)

--Productos que no se vendieron en el actual mes del a�o 2012 (Usando except)
Select Product.Code
From Product
EXCEPT
select SalesDetails.ProductCode from SalesOrder inner join SalesDetails on SalesOrder.OrderNumber= SalesDetails.OrderNumber 
where MONTH(SalesOrder.RequestDate)= MONTH(getdate()) and YEAR(SalesOrder.RequestDate)=2012

--Union: Une 2 tablas que tiene las mismas columnas en una sola tabla
Select Employee.FirstName, Employee.LastName, 'Employee' as Type
From Employee
Union 
Select Customer.FirstName, Customer.LastName, 'Customer' as Type
from Customer

--Busqueda de employes con id= 10 � 2 ; que trabajen siendo asesor
Select *
From  Employee 
WHERE(ID=10 or ID=2) AND
Position= 'Asesor'


--Busqueda de employes con id= 10 o 2; y que trabajen siendo asesor. Mas organizado el parentesis le da la prioridad al or, que al and 
Select *
From  Employee 
WHERE (ID=10 and ID=2) AND 
Position= 'Asesor'

--Not,and, or es el orden de jerarquia



--Problema de tarea
SELECT FirstName+ ' ' + LastName as NameEmployee,
		sum(SoldNumber) as SoldOrders,sum(UnsoldNumber) as UnsoldOrders
FROM
	(
		SELECT  Employee.ID,Employee.FirstName,Employee.LastName, 
				COUNT(SalesOrder.OrderNumber) AS SoldNumber, 0 as UnsoldNumber
		FROM    Employee LEFT JOIN
				SalesOrder ON Employee.ID = SalesOrder.IDEmployee INNER JOIN
				FinalSales ON SalesOrder.OrderNumber =FinalSales.OrderNumber
		GROUP BY Employee.ID, Employee.FirstName,Employee.LastName
 
		UNION
 
		SELECT  Employee.ID,Employee.FirstName, Employee.LastName,0 as SoldNumber, COUNT(SalesOrder.OrderNumber) AS UnsoldNumber
		FROM    Employee LEFT JOIN
				SalesOrder ON Employee.ID = SalesOrder.IDEmployee LEFT JOIN
				FinalSales ON SalesOrder.OrderNumber =FinalSales.OrderNumber
		WHERE   FinalSales.CompletionDate IS NULL
		GROUP BY Employee.ID, Employee.FirstName,Employee.LastName
	) UnionSandUS ---Este nombre puede ser cualquiera; pero debe tener un nombre si o si. Es como el nombre que debe tomar la tabla de la sub-consulta para poder trabajar 
GROUP BY ID,FirstName,LastName


--Por cada venta; quiero el request date y ademas el maxi descuento hecho en el producto
Select SalesOrder.OrderNumber, SalesOrder.RequestDate,
	(SELECT MAX (Discount)
	From SalesDetails as SD
	Where SalesOrder.OrderNumber=SD.OrderNumber
	) as Max_Discount
From SalesOrder 
