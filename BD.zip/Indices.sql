/* sirven para recuperar datos de una tabla, Es como un indice de un libro; sirven para encontar 
rapido un tema*/

--Realmente es una estrucutra de datos que se crea en una tabla para mejorar la velocidad de busqueda de registros
--Se guardan en arboles llamados B-Trees

/* Las mas clasicas son los arboles B-Trees, que son arboles balanceados, que se dividen en nodos, y cada nodo. 
Y los indices Hash,que son mas rapidos pero no se pueden usar en todas las consultas*/

use AdventureWorks2017

--Tipos de indices:
Indices cluster
Indices no cluster
Indices filtrados
Indices Heap --No tiene ningun indice

--Sintaxis: 
CREATE INDEX nombre_indice ON nombre_tabla (columna1, columna2, columna3, ...);

--Consultar los indices de una tabla
Select * from sys.indexes where object_id = object_id('[dbo].[TestProduct]');

Select * from sys.indexes where object_id = object_id('[HumanResources].[Employee]');

--Listar los indices con las columnas que lo componen, de una tabla
Select i.name AS IndexName ,
        COL_NAME(ic.object_id, ic.column_id) AS ColumnName
FROM sys.indexes AS i
JOIN sys.index_columns AS ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
WHERE i.object_id = OBJECT_ID('[HumanResources].[Employee]');

--Verficar si un indice esta siendo utilizado
Select s.user_seeks, s.user_scans, s.user_lookups, s.user_updates, i.name as IndexName
from sys.dm_db_index_usage_stats s 
join sys.indexes i on s.object_id = i.object_id and s.index_id = i.index_id
where s.object_id = object_id('[HumanResources].[Employee]');

--Consultas para crear usos de indices 
Select count (*) From [HumanResources].[Employee]
Select count (*) From [HumanResources].[Employee] group by OrganizationLevel

--Crear una nueva tabla desde person para que no tenga indices
Select * into Person.Person_NoIndex from Person.Person --Esto tambien sirve para crear una nueva tabla con la info de person, pero sin los indices

--Verificar que la tabla person.person_noindex no tiene indices
Select * from sys.indexes where object_id = object_id('[Person].[Person_NoIndex]');

--Medir tiempo de ejecucion de una consulta
SET STATISTICS TIME ON
Select FirstName, LastName from Person.Person_NoIndex where LastName = 'Smith'
SET STATISTICS TIME OFF

--Ahora con el indice de la tabla person.person
SET STATISTICS TIME ON
Select FirstName, LastName from Person.Person where LastName = 'Smith'
SET STATISTICS TIME OFF


---------------------------------------------------------------------------------------------------------------------------------------
/*Indice no clusterizado: Es un indice que se crea aparte de la tabla, y que no afecta la estructura de la tabla */

--Crear un indice no clusterizado
CREATE NONCLUSTERED INDEX IDX_LastName ON Person.Person_NoIndex(LastName, FirstName); --Dentro de los parentesis van los campos que se van a poner en el indice

--Drop index Person.Person_NoIndex.IDX_LastName --Para borrar un indice

Alter NONCLUSTERED Index IDX_LastName on Person.Person_NoIndex Rebuild
Include (NewColumn1, NewColumn2, NewColumn3) --Para Alter un indice no clusterizado, y agregarle columnas

SET STATISTICS TIME ON
Select FirstName, LastName from Person.Person_NoIndex where LastName = 'Smith'
SET STATISTICS TIME OFF
--Si yo llamo una columna que no este en el Indice No Cluster; la consulta se va a demorar pero es buscando la columna que no esta en el Indice No cluster

SET STATISTICS TIME ON
Select FirstName, LastName 
FROM Person.Person_NoIndex 
WHERE LastName = 'Smith' AND FirstName LIKE 'J%'
Order by LastName, FirstName
SET STATISTICS TIME OFF

--Limpiar la cache de SQL Server
CHECKPOINT
DBCC DROPCLEANBUFFERS
DBCC FREEPROCCACHE

----------------------------------------------------------------------------------------------------------------------------------------------------------------------
/*Indice Clusterizado: Es un indice que se crea en la tabla, y que afecta la estructura de la tabla. 
Pero ojo solo se puede hacer 1 solo indice cluster por tabla. Casi siempre este indice la toma la PK */

--Crar una copia de la tabla Sales.SalesOrderDetail
Select * into Sales.SalesOrderDetail_NoIndex from Sales.SalesOrderDetail

--Verificar que la tabla Sales.SalesOrderDetail_Cluster no tiene indices
Select * from sys.indexes where object_id = object_id('[Sales].[SalesOrderDetail_NoIndex]');

--Crear un indice clusterizado
Create Clustered Index IDX_SalesOrderID on Sales.SalesOrderDetail_NoIndex(SalesOrderID); --Crear un indice clusterizado
Drop index Sales.SalesOrderDetail_NoIndex.IDX_SalesOrderID --Para borrar un indice

--Consulta para probar el indice clusterizado
Set STATISTICS TIME ON
Select SUM(LineTotal) as 'Numero de lineas' from Sales.SalesOrderDetail_NoIndex
Where SalesOrderID between 100000 and 100500
Set STATISTICS TIME OFF

/*Crear la llave primaria de la tabla clonada Sales.SalesOrderDetail_NoIndex, 
esto se debe a que como la PK es un indice clusterizado, no se puede hacer un indice clusterizado en la tabla clonada*/
Alter Table Sales.SalesOrderDetail_NoIndex
Add Constraint PK_SalesOrderDetail_NoIndex Primary Key Clustered (SalesOrderDetailID)

--Recordar el nombre de la PK de la tabla
Select name as ContraintName
from sys.key_constraints
where type= 'PK' and parent_object_id = OBJECT_ID('Sales.SalesOrderDetail_NoIndex')

/*Acordarse que si tienes una PK, he intentas hacer un indice cluster de esa PK, te va a decir que nolas. 
(ademas de que no te va a dejar hacer el indice cluster)*/
----------------------------------------------------------------------------------------------------------------------------------------------------------

/*indices filtrados: Son indices que se crean con una condicion, y solo se crean con los registros que cumplan esa condicion*/

--Crear el indice filtrado
Create NONCLUSTERED INDEX idx_SalesOrderDetail_Discounts on Sales.SalesOrderDetail_NoIndex(UnitPriceDiscount, SalesOrderID, ProductID
, UnitPrice)
Where UnitPriceDiscount > 0.0

--Eliminar el indice filtrado
Drop index Sales.SalesOrderDetail_NoIndex.idx_SalesOrderDetail_Discounts

--Consulta para probar 
SET STATISTICS TIME ON
Select SalesOrderID, ProductID, UnitPrice, UnitPriceDiscount
From sales.SalesOrderDetail_NoIndex
Where UnitPriceDiscount > 0.0
SET STATISTICS TIME OFF
