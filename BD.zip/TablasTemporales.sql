/*tablas temporales; sirven para crear unas tablas que no son para siempre; esta se puede ejecutar siempre y cuando lo eejcutes en la querie donde esta la tabla
Son eficientes; si sabes que solo vas a hacer una consulta una sola vez; es preferible este tipo de tablas; que una normal*/

use adventureworks2017;

Create table #month_price (  ----El # indica que es una tabla temporal; y si le pones ## es una tabla global temporal
    month int,
    price money
)

declare @month int=12;
declare @i int=1;

while @i<=@month
begin
    insert into #month_price (month, price)
    values (@i,(100000*(@i*0.01)))
    set @i=@i+1
end

select * from #month_price


/*Tablas sistematicas; son tablas que se crean a partir de una consulta; se crean con la palabra reservada INTO. Deben tener una clave primaria, columnas de periodo
*/

create database pruebas;
use pruebas;

Create table ProductInventory(
    ProductID int Primary key,
    ProductName nvarchar(100),
    Quantity int,
    Price decimal(10,2),
    ValidFrom DATETIME2 GENERATED ALWAYS AS ROW START,
    ValidTo DATETIME2 GENERATED ALWAYS AS ROW END,
    PERIOD FOR SYSTEM_TIME (ValidFrom, ValidTo)
)
WITH (SYSTEM_VERSIONING = ON (HISTORY_TABLE = dbo.ProductInventoryHistory)); --aqui se crea la tabla historica; y se le da el nombre


--Para borrar tablas sistematicas, y la tabla de historico
IF OBJECT_ID('dbo.ProductInventory', 'U') IS NOT NULL
BEGIN 
ALter table dbo.ProductInventory set (SYSTEM_VERSIONING = OFF)
Drop table dbo.ProductInventory
IF OBJECT_ID('dbo.ProductInventoryHistory', 'U') IS NOT NULL
BEGIN
    Drop table dbo.ProductInventoryHistory
END
END

--Para insertar datos en la tabla sistematica
insert into ProductInventory (ProductID, ProductName, Quantity, Price)
values (1, 'Laptop', 50, 4200000);
select * from ProductInventory

--Para actualizar datos en la tabla sistematica
update ProductInventory
set Quantity=45, Price=2150000.00
where ProductID=1

Select * from ProductInventory
Select * from ProductInventoryHistory

Select * from ProductInventory
for system_time all   --para ver todos los datos de la tabla sistematica, puedes hacer as of, from , between, contained, etc
where ProductID=1

